import os
from datetime import datetime
import random
from functools import wraps
from dotenv import load_dotenv
from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from bson import ObjectId
from los_prediction import predict_los_and_explain

load_dotenv()

app = Flask(__name__)
CORS(app) # Allows your Next.js frontend to communicate with Flask

# Configuration
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "fallback-secret-key")
jwt = JWTManager(app)

# MongoDB Connection
client = MongoClient(os.getenv("MONGO_URI", "mongodb://localhost:27017/"))
db = client.smarthospital

# Collections
users_col = db.users
doctors_col = db.doctors
appointments_col = db.appointments
wards_col = db.wards
beds_col = db.beds

# ==========================================
# HELPER: Serialize MongoDB Objects
# ==========================================
def serialize_doc(doc):
    """Safely converts MongoDB documents to JSON-serializable dictionaries"""
    if not doc:
        return doc
        
    # 1. Convert the main _id to 'id' (Standard for frontend)
    if '_id' in doc:
        doc['id'] = str(doc['_id'])
        del doc['_id']
        
    # 2. Find any other ObjectIds (like wardId) and convert them to strings
    for key in list(doc.keys()):
        if isinstance(doc[key], ObjectId):
            doc[key] = str(doc[key])
            
    return doc

# ==========================================
# 0. CUSTOM RBAC DECORATOR
# ==========================================
def role_required(allowed_roles):
    """Decorator to enforce role-based access control"""
    def decorator(fn):
        @wraps(fn)
        @jwt_required()
        def wrapper(*args, **kwargs):
            current_user_id = get_jwt_identity()
            user = users_col.find_one({"_id": ObjectId(current_user_id)})
            
            if not user or user.get("role") not in allowed_roles:
                return jsonify({"msg": "Unauthorized access. Invalid role."}), 403
            
            return fn(*args, **kwargs)
        return wrapper
    return decorator


# ==========================================
# 1. AUTHENTICATION (Register & Login)
# ==========================================
@app.route('/api/status', methods=['GET'])
def status():
    return jsonify({"msg": "API is running"}), 200

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    if users_col.find_one({"email": data.get("email")}):
        return jsonify({"msg": "Email already exists"}), 400

    hashed_password = generate_password_hash(data.get("password"))
    new_user = {
        "firstName": data.get("firstName"),
        "lastName": data.get("lastName"),
        "email": data.get("email"),
        "password": hashed_password,
        "role": data.get("role", "patient") # admin, staff, patient
    }
    users_col.insert_one(new_user)
    return jsonify({"msg": "User registered successfully"}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    user = users_col.find_one({"email": data.get("email")})
    
    if user and check_password_hash(user['password'], data.get("password")):
        access_token = create_access_token(identity=str(user['_id']))
        return jsonify({
            "token": access_token, 
            "role": user.get("role"),
            "name": f"{user.get('firstName')} {user.get('lastName')}"
        }), 200
        
    return jsonify({"msg": "Invalid credentials"}), 401


# ==========================================
# 2. OPD QUEUE & DOCTORS
# ==========================================
@app.route('/api/doctors', methods=['GET'])
@jwt_required() # Any logged-in user can view doctors
def get_doctors_and_queues():
    doctors = list(doctors_col.find())
    response = []
    
    for doc in doctors:
        # Calculate real-time queue data for this doctor
        waiting_count = appointments_col.count_documents({
            "doctorId": str(doc['_id']), 
            "status": {"$in": ["Upcoming", "Ready"]}
        })
        
        doc_data = serialize_doc(doc)
        doc_data['patientsWaiting'] = waiting_count
        doc_data['estimatedWaitTime'] = waiting_count * doc.get('avgConsultationTime', 15)
        response.append(doc_data)
        
    return jsonify(response), 200


# ==========================================
# 3. APPOINTMENTS & VIRTUAL WAITING ROOM
# ==========================================
@app.route('/api/appointments', methods=['POST'])
@jwt_required() # Must be logged in to book
def create_appointment():
    current_user_id = get_jwt_identity()
    data = request.json
    doctor_id = data.get("doctorId")
    
    # Generate a random token (e.g., T-1024)
    token = f"T-{random.randint(1000, 9999)}"
    
    # Calculate position in queue for today
    position = appointments_col.count_documents({
        "doctorId": doctor_id,
        "status": {"$in": ["Upcoming", "Ready", "In Consultation"]}
    })
    
    new_apt = {
        "patientId": current_user_id, # Link appointment to the logged-in user!
        "patientName": data.get("patientName"),
        "department": data.get("department"),
        "doctorId": doctor_id,
        "date": data.get("date"),
        "time": data.get("time"),
        "token": token,
        "position": position,
        "status": "Upcoming", # Upcoming, Ready, In Consultation, Completed
        "createdAt": datetime.now()
    }
    
    apt_id = appointments_col.insert_one(new_apt).inserted_id
    
    return jsonify({"msg": "Appointment booked", "token": token, "id": str(apt_id)}), 201

@app.route('/api/queue/waiting-room', methods=['GET'])
@jwt_required()
def get_waiting_room():
    current_user_id = get_jwt_identity()
    user = users_col.find_one({"_id": ObjectId(current_user_id)})
    
    if not user:
        return jsonify({"msg": "User not found"}), 404

    # Patient role: Only fetch their own active appointments
    if user.get("role") == "patient":
        active_apts = list(appointments_col.find({
            "patientId": current_user_id, 
            "status": {"$ne": "Completed"}
        }).sort("position", 1))
    
    # Staff/Admin role: Fetch ALL active appointments across the hospital
    else:
        active_apts = list(appointments_col.find({"status": {"$ne": "Completed"}}).sort("position", 1))
        
    return jsonify([serialize_doc(apt) for apt in active_apts]), 200

@app.route('/api/queue/update-status/<appointment_id>', methods=['PUT'])
@role_required(["staff", "admin"]) # ONLY Receptionist/Admin can modify queues
def update_appointment_status(appointment_id):
    status = request.json.get("status")
    appointments_col.update_one(
        {"_id": ObjectId(appointment_id)},
        {"$set": {"status": status}}
    )
    return jsonify({"msg": "Status updated successfully"}), 200


# ==========================================
# 4. BED AVAILABILITY & STAFF MANAGEMENT
# ==========================================
@app.route('/api/wards', methods=['GET', 'POST'])
@role_required(["staff", "admin"])
def manage_wards():
    if request.method == 'POST':
        data = request.json
        new_ward = {
            "name": data.get("name"),
            "totalBeds": int(data.get("totalBeds", 0)),
            "occupiedBeds": 0,
            "predictedVacancy": "N/A"
        }
        ward_id = wards_col.insert_one(new_ward).inserted_id
        
        # Auto-generate the empty beds for this new ward!
        beds_to_insert = []
        bed_type = "Standard"
        if "ICU" in new_ward["name"].upper(): bed_type = "Ventilator Support"
        elif "MATERNITY" in new_ward["name"].upper() or "PRIVATE" in new_ward["name"].upper(): bed_type = "Private"

        for i in range(1, new_ward["totalBeds"] + 1):
            beds_to_insert.append({
                "wardId": str(ward_id), # Stored as string to match frontend
                "ward": new_ward["name"],
                "bedNumber": str(i),
                "type": bed_type,
                "status": "Available",
                "patient": "-"
            })
            
        if beds_to_insert:
            beds_col.insert_many(beds_to_insert)

        return jsonify({"msg": "Ward and beds created successfully!"}), 201

    # If it's a GET request:
    wards = list(wards_col.find())
    return jsonify([serialize_doc(ward) for ward in wards]), 200


@app.route('/api/beds', methods=['GET', 'POST'])
@role_required(["staff", "admin"])
def manage_beds():
    if request.method == 'POST':
        data = request.json
        new_bed = {
            "wardId": data['wardId'],
            "ward": data['wardName'],
            "bedNumber": data.get('bedNumber', '0'),
            "type": data['type'],
            "status": data.get('status', 'Available'),
            "patient": data.get('patient', '-')
        }
        beds_col.insert_one(new_bed)
        
        # Update ward totals
        wards_col.update_one({"_id": ObjectId(data['wardId'])}, {"$inc": {"totalBeds": 1}})
        if new_bed['status'] == 'Occupied':
            wards_col.update_one({"_id": ObjectId(data['wardId'])}, {"$inc": {"occupiedBeds": 1}})
            
        return jsonify({"msg": "Bed added successfully"}), 201

    # If it's a GET request:
    beds = list(beds_col.find())
    return jsonify([serialize_doc(bed) for bed in beds]), 200


@app.route('/api/beds/<bed_id>', methods=['PUT', 'DELETE'])
@role_required(["staff", "admin"])
def update_or_delete_bed(bed_id):
    if request.method == 'DELETE':
        bed = beds_col.find_one({"_id": ObjectId(bed_id)})
        if bed:
            beds_col.delete_one({"_id": ObjectId(bed_id)})
            
            # Decrease totals on the ward
            wards_col.update_one({"_id": ObjectId(bed['wardId'])}, {"$inc": {"totalBeds": -1}})
            if bed.get('status') == 'Occupied':
                wards_col.update_one({"_id": ObjectId(bed['wardId'])}, {"$inc": {"occupiedBeds": -1}})
                
        return jsonify({"msg": "Bed deleted"}), 200

    # If it's a PUT request (Update Status/Patient):
    data = request.json
    update_fields = {}
    if "status" in data: update_fields["status"] = data["status"]
    if "patient" in data: update_fields["patient"] = data["patient"]
    if "type" in data: update_fields["type"] = data["type"]

    beds_col.update_one({"_id": ObjectId(bed_id)}, {"$set": update_fields})
    
    # Recalculate ward occupancy
    bed = beds_col.find_one({"_id": ObjectId(bed_id)})
    if bed:
        ward_id = bed.get("wardId")
        occupied_count = beds_col.count_documents({"wardId": ward_id, "status": "Occupied"})
        wards_col.update_one({"_id": ObjectId(ward_id)}, {"$set": {"occupiedBeds": occupied_count}})
        
    return jsonify({"msg": "Bed status updated"}), 200



# ==========================================
# 5. MACHINE LEARNING: LOS PREDICTION
# ==========================================
@app.route('/api/predict-los', methods=['POST'])
@jwt_required()
def predict_los():
    data = request.json
    result = predict_los_and_explain(data)
    
    if "error" in result:
        return jsonify(result), 500
        
    return jsonify(result), 200





if __name__ == '__main__':
    app.run(port=int(os.getenv("PORT", 5000)), debug=True)