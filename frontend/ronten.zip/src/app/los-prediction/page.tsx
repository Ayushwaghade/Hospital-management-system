"use client";

import { useState } from "react";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { BrainCircuit, Loader2, Activity, AlertCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, Cell, ReferenceLine } from "recharts";
import { api } from "@/lib/axios";

export default function LOSPredictionPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  // Default patient values (similar to your notebook sample)
  const [formData, setFormData] = useState({
    rcount: "1", gender: "1", dialysisrenalendstage: "0", asthma: "0", irondef: "0", pneum: "0",
    substancedependence: "0", psychologicaldisordermajor: "0", depress: "0", psychother: "0",
    fibrosisandother: "0", malnutrition: "0", hemo: "13", hematocrit: "40", neutrophils: "8",
    sodium: "138", glucose: "120", bloodureanitro: "12", creatinine: "1.0", bmi: "28", pulse: "80",
    respiration: "6", secondarydiagnosisnonicd9: "1", facid_B: "1", facid_C: "0", facid_D: "0", facid_E: "0"
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({ ...formData, [name]: value });
  };

  const runPrediction = async () => {
    setLoading(true);
    try {
      const res = await api.post('/predict-los', formData);
      setResult(res.data);
    } catch (error) {
      console.error("Prediction failed:", error);
      alert("Failed to run prediction. Check console for details.");
    } finally {
      setLoading(false);
    }
  };

  const getPredictionText = (predClass: number) => {
    switch (predClass) {
      case 0: return { text: "Short Stay (1–3 days)", color: "text-emerald-600", bg: "bg-emerald-100" };
      case 1: return { text: "Medium Stay (4–6 days)", color: "text-amber-600", bg: "bg-amber-100" };
      case 2: return { text: "Long Stay (7+ days)", color: "text-rose-600", bg: "bg-rose-100" };
      default: return { text: "Unknown", color: "text-gray-600", bg: "bg-gray-100" };
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <BrainCircuit className="w-6 h-6 text-primary" />
            AI Length of Stay Predictor
          </h2>
          <p className="text-muted-foreground">CatBoost ML Model with SHAP Feature Explainability</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* LEFT: INPUT FORM */}
          <Card className="lg:col-span-7 border-none shadow-sm">
            <CardHeader>
              <CardTitle>Patient Clinical Data</CardTitle>
              <CardDescription>Input vitals and history to predict admission duration.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <Select value={formData.gender} onValueChange={(v) => handleSelectChange("gender", v)}>
                    <SelectTrigger><SelectValue/></SelectTrigger>
                    <SelectContent><SelectItem value="1">Male</SelectItem><SelectItem value="0">Female</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="space-y-2"><Label>BMI</Label><Input type="number" name="bmi" value={formData.bmi} onChange={handleInputChange} /></div>
                <div className="space-y-2"><Label>Pulse</Label><Input type="number" name="pulse" value={formData.pulse} onChange={handleInputChange} /></div>
                <div className="space-y-2"><Label>Respiration</Label><Input type="number" name="respiration" value={formData.respiration} onChange={handleInputChange} /></div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2"><Label>Hemo</Label><Input type="number" name="hemo" value={formData.hemo} onChange={handleInputChange} /></div>
                <div className="space-y-2"><Label>Neutrophils</Label><Input type="number" name="neutrophils" value={formData.neutrophils} onChange={handleInputChange} /></div>
                <div className="space-y-2"><Label>Glucose</Label><Input type="number" name="glucose" value={formData.glucose} onChange={handleInputChange} /></div>
                <div className="space-y-2"><Label>Sodium</Label><Input type="number" name="sodium" value={formData.sodium} onChange={handleInputChange} /></div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Facility ID</Label>
                  <Select value={formData.facid_B === "1" ? "B" : formData.facid_E === "1" ? "E" : "A"} 
                    onValueChange={(v) => {
                      setFormData({...formData, facid_B: v==="B"?"1":"0", facid_C: v==="C"?"1":"0", facid_D: v==="D"?"1":"0", facid_E: v==="E"?"1":"0"})
                  }}>
                    <SelectTrigger><SelectValue/></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A">Facility A</SelectItem>
                      <SelectItem value="B">Facility B</SelectItem>
                      <SelectItem value="E">Facility E</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Asthma</Label>
                  <Select value={formData.asthma} onValueChange={(v) => handleSelectChange("asthma", v)}>
                    <SelectTrigger><SelectValue/></SelectTrigger>
                    <SelectContent><SelectItem value="1">Yes</SelectItem><SelectItem value="0">No</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Dialysis (ESRD)</Label>
                  <Select value={formData.dialysisrenalendstage} onValueChange={(v) => handleSelectChange("dialysisrenalendstage", v)}>
                    <SelectTrigger><SelectValue/></SelectTrigger>
                    <SelectContent><SelectItem value="1">Yes</SelectItem><SelectItem value="0">No</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Pneumonia</Label>
                  <Select value={formData.pneum} onValueChange={(v) => handleSelectChange("pneum", v)}>
                    <SelectTrigger><SelectValue/></SelectTrigger>
                    <SelectContent><SelectItem value="1">Yes</SelectItem><SelectItem value="0">No</SelectItem></SelectContent>
                  </Select>
                </div>
              </div>

              <Button onClick={runPrediction} disabled={loading} className="w-full h-12 text-lg mt-4">
                {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Activity className="w-5 h-5 mr-2" />}
                Analyze Patient Data
              </Button>
            </CardContent>
          </Card>

          {/* RIGHT: PREDICTION & SHAP EXPLAINER */}
          <div className="lg:col-span-5 space-y-6">
            {!result ? (
              <Card className="border-dashed bg-secondary/10 h-full flex flex-col justify-center items-center text-muted-foreground p-8 text-center min-h-[400px]">
                <BrainCircuit className="w-16 h-16 mb-4 opacity-20" />
                <p>Run the analysis to view ML predictions and feature importance.</p>
              </Card>
            ) : (
              <>
                <Card className="border-none shadow-sm overflow-hidden">
                  <div className={`p-6 ${getPredictionText(result.prediction).bg}`}>
                    <p className="text-sm font-semibold uppercase tracking-wider mb-1 opacity-80">Predicted Length of Stay</p>
                    <h3 className={`text-3xl font-bold ${getPredictionText(result.prediction).color}`}>
                      {getPredictionText(result.prediction).text}
                    </h3>
                  </div>
                  <CardContent className="p-6 space-y-4">
                    <p className="font-semibold text-sm">Model Confidence:</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm"><span className="text-emerald-700">Short (1-3d)</span><span>{result.probabilities[0]}%</span></div>
                      <Progress value={result.probabilities[0]} className="h-2 [&>div]:bg-emerald-500" />
                      
                      <div className="flex justify-between text-sm pt-2"><span className="text-amber-700">Medium (4-6d)</span><span>{result.probabilities[1]}%</span></div>
                      <Progress value={result.probabilities[1]} className="h-2 [&>div]:bg-amber-500" />
                      
                      <div className="flex justify-between text-sm pt-2"><span className="text-rose-700">Long (7+ d)</span><span>{result.probabilities[2]}%</span></div>
                      <Progress value={result.probabilities[2]} className="h-2 [&>div]:bg-rose-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-md flex items-center justify-between">
                      SHAP Feature Impact
                      <AlertCircle className="w-4 h-4 text-muted-foreground" />
                    </CardTitle>
                    <CardDescription className="text-xs">
                      What drove the model to pick {getPredictionText(result.prediction).text}?
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[280px] w-full mt-4">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={result.shap_values} layout="vertical" margin={{ top: 0, right: 30, left: 40, bottom: 0 }}>
                          <XAxis type="number" hide />
                          <YAxis dataKey="feature" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 11 }} width={90} />
                          <RechartsTooltip 
                            formatter={(val: number) => [val.toFixed(3), "Impact"]}
                            labelStyle={{ color: "black" }}
                          />
                          <ReferenceLine x={0} stroke="#cbd5e1" />
                          <Bar dataKey="impact" radius={[0, 4, 4, 0]} barSize={16}>
                            {result.shap_values.map((entry: any, index: number) => (
                              <Cell key={`cell-${index}`} fill={entry.impact > 0 ? "#ef4444" : "#10b981"} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex justify-center gap-4 text-xs text-muted-foreground mt-2">
                      <span className="flex items-center gap-1"><span className="w-3 h-3 bg-emerald-500 rounded-sm"></span> Pushes LOS Down</span>
                      <span className="flex items-center gap-1"><span className="w-3 h-3 bg-red-500 rounded-sm"></span> Pushes LOS Up</span>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}