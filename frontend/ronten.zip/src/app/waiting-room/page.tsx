"use client";

import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Monitor, RefreshCcw, Clock, Loader2 } from "lucide-react";
import { api } from "@/lib/axios";
import { Button } from "@/components/ui/button";

// Interface matching the backend appointment data
interface Appointment {
  id: string;
  token: string;
  patientName: string;
  department: string;
  position: number;
  status: string;
  doctorId: string; // Needed for our stats calculation
}

export default function WaitingRoomPage() {
  const [timeLeft, setTimeLeft] = useState(15 * 60);
  const [patients, setPatients] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState<string | null>(null);
  
  // New state for live queue statistics
  const [queueStats, setQueueStats] = useState({ avgWait: 0, completed: 0 });

  // Fetch the live waiting room data
  const fetchWaitingRoom = async () => {
    setLoading(true);
    try {
      const response = await api.get('/queue/waiting-room');
      const patientsData = response.data;
      setPatients(patientsData);

      // If user is staff/admin, calculate the real-time statistics
      const currentRole = localStorage.getItem("role");
      if (currentRole === "staff" || currentRole === "admin") {
        const docsRes = await api.get('/doctors');
        const doctors = docsRes.data;

        // 1. Calculate Real Average Wait Time
        let calculatedAvgWait = 0;
        const docsWithQueues = doctors.filter((d: any) => d.patientsWaiting > 0);
        if (docsWithQueues.length > 0) {
          const totalWaitTime = docsWithQueues.reduce((acc: number, doc: any) => acc + doc.estimatedWaitTime, 0);
          calculatedAvgWait = Math.round(totalWaitTime / docsWithQueues.length);
        }

        // 2. Cleverly estimate Completed Consultations
        // We look at the highest position number assigned today, minus who is still waiting!
        let estimatedCompleted = 0;
        doctors.forEach((doc: any) => {
          const docPatients = patientsData.filter((p: Appointment) => p.doctorId === doc.id);
          if (docPatients.length > 0) {
            const maxPosition = Math.max(...docPatients.map((p: Appointment) => p.position));
            // If the highest position is 10, but only 4 are waiting, 6 must be completed!
            estimatedCompleted += Math.max(0, maxPosition - docPatients.length);
          }
        });

        setQueueStats({ avgWait: calculatedAvgWait, completed: estimatedCompleted });
      }

    } catch (error) {
      console.error("Failed to fetch waiting room data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setRole(localStorage.getItem("role"));
    fetchWaitingRoom();

    // Visual Timer countdown logic
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Ready": return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "In Consultation": return "bg-blue-100 text-blue-700 border-blue-200";
      case "Upcoming": return "bg-secondary text-secondary-foreground border-transparent";
      default: return "";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Virtual Waiting Room</h2>
          <p className="text-muted-foreground">
            {role === "patient" ? "Track your appointment status in real-time." : "Live overview of all active patient queues."}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-2 border-none shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Monitor className="w-5 h-5 text-primary" />
                Live Waiting List
              </CardTitle>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={fetchWaitingRoom} 
                disabled={loading}
              >
                <RefreshCcw className={`w-4 h-4 text-muted-foreground ${loading ? 'animate-spin' : ''}`} />
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center p-8">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : patients.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground bg-secondary/20 rounded-lg border border-dashed">
                  No patients currently in the waiting room.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Token</TableHead>
                      <TableHead>Patient Name</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {patients.map((p) => (
                      <TableRow key={p.id}>
                        <TableCell className="font-bold text-primary">{p.token}</TableCell>
                        <TableCell>{p.patientName}</TableCell>
                        <TableCell>{p.department}</TableCell>
                        <TableCell>
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-secondary text-xs font-bold">
                            {p.position}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={getStatusColor(p.status)}>
                            {p.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Stats Column */}
          <div className="space-y-6">
            <Card className="border-none shadow-sm bg-primary text-primary-foreground">
              <CardContent className="p-6 text-center">
                <Clock className="w-10 h-10 mx-auto mb-4 opacity-75" />
                <h3 className="text-sm font-medium opacity-90 mb-1">
                  {role === "patient" ? "Estimated Wait for Your Turn" : "Estimated Wait for Next Patient"}
                </h3>
                <div className="text-4xl font-bold font-mono tracking-tighter">
                  {patients.length > 0 ? formatTime(timeLeft) : "0:00"}
                </div>
              </CardContent>
            </Card>

            {/* Only show full queue stats to staff/admin */}
            {role !== "patient" && (
              <Card className="border-none shadow-sm">
                <CardHeader>
                  <CardTitle className="text-md">Queue Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Total Waiting</span>
                    <span className="font-bold">{patients.length}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Avg Wait Today</span>
                    <span className="font-bold">{queueStats.avgWait} min</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Consultations Done</span>
                    <span className="font-bold text-emerald-600">{queueStats.completed}</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}